//
//  CTile.cpp
//  Pokimac
//
//  Created by LouLiLou on 01/01/2022.
//

#include "CTile.hpp"

CTile::CTile() {
    tileID = 0;
    typeID = TILE_TYPE_NONE;
}
