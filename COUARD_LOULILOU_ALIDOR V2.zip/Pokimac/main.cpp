//
//  main.cpp
//  Pokimac
//
//  Created by LouLiLou on 30/12/2021.
//

#include "CApp.h"

int main(int argc, char * argv[]) {
    CApp theApp((char *) argv[0]);
    return theApp.OnExecute();
}
