Pokimac est un jeu créé par LouLiLou (Lilou ALIDOR et Lou COUARD) lors du projet de C au S1 de l'IMAC en 2022.

Le jeu se joue à la souris et aux flèches du clavier.
Les règles complètes sont indiquées lors du lancement du jeu en cliquant sur le bouton "règles" (il y a 3 pages de règles).

Pour compiler le jeu, installez les librairies SDL1.2.15, SDL_ttf2.0 (pour SDL1.2), et SDL_image1.2 (pour SDL1.2).

Sous Linux et Mac, compilez en modifiant le makefile (link de librairies à modifier).
Sous Windows, assurez vous que vous compilez avec MinGW32 avec la commande 32 bits. (Code::Blocks recommandé).

Tous les dossiers doivent se trouver à l'endroit de l'exécutable.

Vérifiez que vous pouvez compiler les librairies 1.2 avant de compiler le jeu.

Si vous avez des questions, Stack Overflow est votre ami.